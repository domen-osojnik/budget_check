package com.example.budgetcheck.events;

public class NewTransactionEvent {
}
