package com.example.datastructurelib;

public class Events {
    public static class TransactionEvent {
        //ko uporabnik doda transakcijo
    }

    public static class LoginEvent {
        //ko se uporabnik prijavi
    }

    public static class LogoutEvent {
        //ko se uporabnik odjavi
    }
}
